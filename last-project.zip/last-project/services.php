<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complete glass website</title>
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <!--===== GSAP =====-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.5.1/gsap.min.js"></script>
  <!-- font awesome cdn link  -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <!-- custom css file link  -->
  <link rel="stylesheet" href="assets/css/services-css/style.css">
</head>
<body>

<!-- header section starts  -->
<div class="glass-container">
 <header class="header">
    <a href="#" class="logo">AIM</a>
    <div class="icons">
        <div class="fas fa-moon" id="theme-btn"></div>
        <div class="fas fa-palette" id="color-btn"></div>
        <div class="fas fa-search" id="search-btn"></div>
        <div class="fas fa-bars" id="menu-btn"></div>
    </div>
    <nav class="navbar">
        <a class="active" href="index.php">Home</a>
        <a href="services.php">Services</a>
        <a href="gallery.php">Gallery</a>
        <a href="about.php">About us</a>
        <a href="code.php">Code</a>
        <a href="contact.php">Contact</a>
        <a href="login.php">login</a>
    </nav>
    <form action="" class="search-form">
        <input type="search" name="" placeholder="search here..." id="search-box">
        <label for="search-box" class="fas fa-search"></label>
    </form>
    <div class="colors-palette">
        <h3>choose color</h3>
        <div class="colors">
            <div class="color" style="background:#2980b9"></div>
            <div class="color" style="background: #27ae60;"></div>
            <div class="color" style="background: #e74c3c;"></div>
            <div class="color" style="background: #8e44ad;"></div>
            <div class="color" style="background: #B33771;"></div>
            <div class="color" style="background: #0fb9b1;"></div>
            <div class="color" style="background: #ff9f1a;"></div>
            <div class="color" style="background: #e84393;"></div>
            <div class="color" style="background: #17c0eb;"></div>
        </div>
    </div>
 </header>
 <!-- header section ends -->

  <section class="main" id="main">
      <div class="content">
        <h2>See our<br><span>Services</span></h2>
        <div class="animated-text">
          <h3>Web Designer</h3>
          <h3>Web Developer</h3>
          <h3>Motion Graphic Designer</h3>
        </div><br>
        <a href="#" class="btn">choose plan</a>
      </div>
      <img class="GIF" src="assets/images/header/5.png">
    </section>
    </div>
    <div class="circle1"></div>
    <div class="circle2"></div>
 <!-- header end -->

  
 <!-- services section starts  -->
 <br><br><section class="services" id="services">
 <h1 class="heading">our<span>services</span></h1>
 <div class="box-container">
    <div class="box">
        <i class="fas fa-code"></i>
        <h3>web design</h3>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Magni, iste.</p>
    </div>
    <div class="box">
        <i class="fas fa-mobile"></i>
        <h3>responsive</h3>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Magni, iste.</p>
    </div>
    <div class="box">
        <i class="fas fa-palette"></i>
        <h3>custom design</h3>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Magni, iste.</p>
    </div>
    <div class="box">
        <i class="fas fa-bullhorn"></i>
        <h3>seo marketing</h3>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Magni, iste.</p>
    </div>
    <div class="box">
        <i class="fas fa-envelope"></i>
        <h3>email marketing</h3>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Magni, iste.</p>
    </div>
    <div class="box">
        <i class="fas fa-headset"></i>
        <h3>24/7 services</h3>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Magni, iste.</p>
    </div>
 </div>
 <div class="circle1"></div>
  <div class="circle2"></div>
 </section>
 <!-- services section ends -->
    <br><br><h1 class="heading">other<span>services</span></h1>
    <div class="ui-card-main">
    <div class="ui-card">
        <img src="assets/images/services/1.gif">
        <div class="ui-card-description">
            <h3>Mountain Morning</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.</p>
             <a href="#" class="btn">choose plan</a>
        </div>
    </div>
    <div class="ui-card">
        <img src="assets/images/services/2.gif">
        <div class="ui-card-description">
            <h3>Mountain Morning</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.</p>
            <a href="#" class="btn">choose plan</a>
        </div>
    </div>
    <div class="ui-card">
        <img src="assets/images/services/3.gif">
        <div class="ui-card-description">
            <h3>Mountain Morning</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.</p>
            <a href="#" class="btn">choose plan</a>
        </div>
    </div>
    </div>

    <!-- footer section starts  -->
    <?php include 'includes/footer.php' ?>
    <!-- footer section ends -->


    <!-- custom js file link  -->
    <script src="assets/js/script.js"></script>
    <!--=============== MAIN JS ===============-->
    <script src="assets/js/main.js"></script>

</body>
</html>