<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complete glass website</title>
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <!--===== GSAP =====-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.5.1/gsap.min.js"></script>
  <!-- font awesome cdn link  -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <!-- custom css file link  -->
  <link rel="stylesheet" href="assets/css/contact-css/style.css">
</head>
<body>

<!-- header section starts  -->
<div class="glass-container">
 <header class="header">
    <a href="#" class="logo">AIM</a>
    <div class="icons">
        <div class="fas fa-moon" id="theme-btn"></div>
        <div class="fas fa-palette" id="color-btn"></div>
        <div class="fas fa-search" id="search-btn"></div>
        <div class="fas fa-bars" id="menu-btn"></div>
    </div>
    <nav class="navbar">
        <a class="active" href="index.php">Home</a>
        <a href="services.php">Services</a>
        <a href="gallery.php">Gallery</a>
        <a href="about.php">About us</a>
        <a href="code.php">Code</a>
        <a href="contact.php">Contact</a>
        <a href="login.php">login</a>
    </nav>
    <form action="" class="search-form">
        <input type="search" name="" placeholder="search here..." id="search-box">
        <label for="search-box" class="fas fa-search"></label>
    </form>
    <div class="colors-palette">
        <h3>choose color</h3>
        <div class="colors">
            <div class="color" style="background:#2980b9"></div>
            <div class="color" style="background: #27ae60;"></div>
            <div class="color" style="background: #e74c3c;"></div>
            <div class="color" style="background: #8e44ad;"></div>
            <div class="color" style="background: #B33771;"></div>
            <div class="color" style="background: #0fb9b1;"></div>
            <div class="color" style="background: #ff9f1a;"></div>
            <div class="color" style="background: #e84393;"></div>
            <div class="color" style="background: #17c0eb;"></div>
        </div>
    </div>
 </header>
 <!-- header section ends -->

  <section class="main" id="main">
      <div class="content">
        <h2>Here is our<br><span> Conatct</span> Information</h2>
        <div class="animated-text">
          <h3>Aroosha</h3>
          <h3>Rida</h3>
          <h3>Anum</h3>
        </div><br>
        <a href="#" class="btn">choose plan</a>
      </div>
      <img class="GIF" src="assets/images/header/3.png">
    </section>
    </div>
    <div class="circle1"></div>
    <div class="circle2"></div>
 <!-- header end -->
 
 <!-- Contact section start -->
 <br><h1 class="heading"><span>Contact </span>Us</h1>
 <section class="contact" id="contact">
      <div class="title reveal">
      </div>
      <div class="content">
        <div class="row">
          <div class="card reveal">
            <div class="contact-icon">
              <i class="fas fa-map-marker-alt"></i>
            </div>
            <div class="info">
              <h3>Address</h3>
              <span>Address, City, Country</span>
            </div>
          </div>
          <div class="card reveal">
            <div class="contact-icon">
              <i class="fas fa-phone"></i>
            </div>
            <div class="info">
              <h3>Phone</h3>
              <span>+00 0000 000 000</span>
            </div>
          </div>
          <div class="card reveal">
            <div class="contact-icon">
              <i class="fas fa-envelope"></i>
            </div>
            <div class="info">
              <h3>Email</h3>
              <span>contact@email.com</span>
            </div>
          </div>
        </div>   
      </div>
    </section>

  <!-- contact section starts  -->
   <br> <section class="contact" id="contact">
    <h1 class="heading">Share <span> Your </span>Message</h1>
    <form action="">
        <div class="inputBox">
            <input type="text" placeholder="name">
            <input type="email" placeholder="email">
        </div>
        <div class="inputBox">
            <input type="number" placeholder="number">
            <input type="text" placeholder="subject">
        </div>
        <textarea name="" placeholder="your message" id="" cols="30" rows="10"></textarea>
        <input type="submit" value="send message" class="btn">
    </form>
  </section>
  <!-- contact section ends -->

  <!-- footer section starts  -->
   <?php include 'includes/footer.php' ?>
  <!-- footer section ends -->

  
    <!-- custom js file link  -->
    <script src="assets/js/script.js"></script>
    <!--=============== MAIN JS ===============-->
    <script src="assets/js/main.js"></script>

</body>
</html>