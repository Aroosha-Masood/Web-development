<br><br><section class="footer">
    <div class="box-container">
        <div class="box">
            <h3>quick links</h3>
            <a href="#"> <i class="fas fa-chevron-right"></i> home </a>
            <a href="#"> <i class="fas fa-chevron-right"></i> services </a>
            <a href="#"> <i class="fas fa-chevron-right"></i> gallery </a>
            <a href="#"> <i class="fas fa-chevron-right"></i> about </a>
            <a href="#"> <i class="fas fa-chevron-right"></i> code </a>
            <a href="#"> <i class="fas fa-chevron-right"></i> contact </a>
        </div>
        <div class="box">
            <h3>contact info</h3>
            <a href="#"> <i class="fas fa-phone"></i> 000000000</a>
            <a href="#"> <i class="fas fa-phone"></i> +111111111 </a>
            <a href="#"> <i class="fas fa-envelope"></i> ABC@gmail.com </a>
            <a href="#"> <i class="fas fa-envelope"></i> abc@gmail.com </a>
            <a href="#"> <i class="fas fa-map-marker-alt"></i> Toba tek Singh </a>
        </div>
        <div class="box">
            <h3>follow us</h3>
            <a href="#"> <i class="fab fa-facebook-f"></i> facebook </a>
            <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
            <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
            <a href="#"> <i class="fab fa-linkedin"></i> linkedin </a>
            <a href="#"> <i class="fab fa-pinterest"></i> pinterest </a>
        </div>
        <div class="box">
            <h3>follow us</h3>
            <a href="#"> <i class="fab fa-windows"></i> windows </a>
            <a href="#"> <i class="fab fa-apple"></i> app store </a>
            <a href="#"> <i class="fab fa-google-play"></i> play store </a>
        </div>
    </div>
    <div class="credit"> &copy; copyright @ 2021 by <span>Aroosha Masood web designer</span> </div>
  </section>