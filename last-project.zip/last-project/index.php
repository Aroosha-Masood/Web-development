<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complete glass website</title>
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <!--===== GSAP =====-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.5.1/gsap.min.js"></script>
  <!-- font awesome cdn link  -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <!-- custom css file link  -->
  <link rel="stylesheet" href="assets/css/home-css/style.css">
</head>
<body>

<!-- header section starts  -->
<div class="glass-container">
 <header class="header">
    <a href="#" class="logo">AIM</a>
    <div class="icons">
        <div class="fas fa-moon" id="theme-btn"></div>
        <div class="fas fa-palette" id="color-btn"></div>
        <div class="fas fa-search" id="search-btn"></div>
        <div class="fas fa-bars" id="menu-btn"></div>
    </div>
    <nav class="navbar">
        <a class="active" href="index.php">Home</a>
        <a href="services.php">Services</a>
        <a href="gallery.php">Gallery</a>
        <a href="about.php">About us</a>
        <a href="code.php">Code</a>
        <a href="contact.php">Contact</a>
        <a href="login.php">login</a>
    </nav>
    <form action="" class="search-form">
        <input type="search" name="" placeholder="search here..." id="search-box">
        <label for="search-box" class="fas fa-search"></label>
    </form>
    <div class="colors-palette">
        <h3>choose color</h3>
        <div class="colors">
            <div class="color" style="background:#2980b9"></div>
            <div class="color" style="background: #27ae60;"></div>
            <div class="color" style="background: #e74c3c;"></div>
            <div class="color" style="background: #8e44ad;"></div>
            <div class="color" style="background: #B33771;"></div>
            <div class="color" style="background: #0fb9b1;"></div>
            <div class="color" style="background: #ff9f1a;"></div>
            <div class="color" style="background: #e84393;"></div>
            <div class="color" style="background: #17c0eb;"></div>
        </div>
    </div>
 </header>
 <!-- header section ends -->
  <section class="main" id="main">
      <div class="content">
        <h2>Hi! I am<br><span>Aroosha</span></h2>
        <div class="animated-text">
          <h3>Web Developer</h3>
          <h3>Web Designer</h3>
          <h3>Content Writer</h3>
        </div><br>
        <a href="#" class="btn">See More</a>
      </div>
      <img class="GIF" src="assets/images/header/6.gif">
    </section>
    </div>
    <div class="circle1"></div>
    <div class="circle2"></div>
 <!-- header end -->

   
  <!-- about us section starts-->
 <br><br><h1 class="heading">About<span>US</span></h1>
 <div class="profile-card">
    <div class="card-header">
      <div class="pic">
        <img src="assets/images/about/1.jpeg" alt="">
      </div>
      <div class="name">IT BAAR</div>
      <div class="desc">As every organization has a biggest strength behind it and that is their management and team working. Without proper team coordination an organization can’t achieve success. Any institute or an organization is nothing without their team and they can’t even survive.</div>
      <div class="center">
         <div class="icons first">
            <li><a href="https://www.facebook.com/"><span class="fab fa-facebook-f"></span></a></li>
            <li><a href="https://twitter.com/home?lang=en"><span class="fab fa-twitter"></span></a></li>
            <li><a href="https://www.instagram.com/"><span class="fab fa-instagram"></span></a></li>
            <li><a href="https://www.linkedin.com/feed/"><span class="fab fa-linkedin-in"></span></a></li>
            <li><a href="https://github.com/"><span class="fab fa-github"></span></a></li>
         </div>
      </div>
     <script>
         $('.first li').click(function(){
           $(this).toggleClass("shadow-1").siblings();
           $(this).toggleClass("fill-color").siblings();
         });
      </script>
    </div>
    <div class="card-footer">
      <div class="numbers">
        <div class="item">
          <span>Owners</span>2</div>
        <div class="border"></div>
        <div class="item">
          <span>Manager</span>1</div>
        <div class="border"></div>
        <div class="item">
          <span>Team</span>2</div>
      </div>
    </div>
  </div>

 <!-- services section starts  -->
 <br><br><section class="services" id="services">
 <h1 class="heading">our<span>services</span></h1>
 <div class="box-container">
    <div class="box">
        <i class="fas fa-code"></i>
        <h3>web design</h3>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Magni, iste.</p>
    </div>
    <div class="box">
        <i class="fas fa-mobile"></i>
        <h3>responsive</h3>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Magni, iste.</p>
    </div>
    <div class="box">
        <i class="fas fa-palette"></i>
        <h3>custom design</h3>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Magni, iste.</p>
    </div>
    <div class="box">
        <i class="fas fa-bullhorn"></i>
        <h3>seo marketing</h3>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Magni, iste.</p>
    </div>
    <div class="box">
        <i class="fas fa-envelope"></i>
        <h3>email marketing</h3>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Magni, iste.</p>
    </div>
    <div class="box">
        <i class="fas fa-headset"></i>
        <h3>24/7 services</h3>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Magni, iste.</p>
    </div>
 </div>
 <div class="circle1"></div>
  <div class="circle2"></div>
 </section>
 <!-- services section ends -->

  <!-- gallery section starts  -->
  <section class="gallery" id="gallery">
    <h1 class="heading"> our <span>gallery</span> </h1>
    <div class="box-container">
        <div class="box">
            <img src="assets/images/gallery/A1.png" alt="">
            <div class="content">
                <h3>project 01</h3>
                <span>01/09/2021</span>
            </div>
        </div>
        <div class="box">
            <img src="assets/images/gallery/p2.png" alt="">
            <div class="content">
                <h3>project 02</h3>
                <span>01/09/2021</span>
            </div>
        </div>
        <div class="box">
            <img src="assets/images/gallery/A3.png" alt="">
            <div class="content">
                <h3>project 03</h3>
                <span>01/09/2021</span>
            </div>
        </div>
        <div class="box">
            <img src="assets/images/gallery/p3.png" alt="">
            <div class="content">
                <h3>project 04</h3>
                <span>01/09/2021</span>
            </div>
        </div>
        <div class="box">
            <img src="assets/images/gallery/A2.png" alt="">
            <div class="content">
                <h3>project 05</h3>
                <span>01/09/2021</span>
            </div>
        </div>
        <div class="box">
            <img src="assets/images/gallery/p8.png" alt="">
            <div class="content">
                <h3>project 06</h3>
                <span>01/09/2021</span>
            </div>
        </div>
    </div>
 </section>
 <div class="circle1"></div>
 <div class="circle2"></div>
 <!-- gallery section ends -->

  <!-- pricing section starts  -->
  <section class="pricing" id="pricing">
    <h1 class="heading"> our <span>Courses</span> </h1>
    <div class="box-contanier">
        <div class="box">
            <span class="fas fa-code"></span>
            <h3>Web designing</h3>
            <div class="price"> <i>₹</i>2000<i>/monthly</i> </div>
            <ul>
                <li> <i class="fas fa-check"></i> 2 months </li>
                <li> <i class="fas fa-check"></i> practicals </li>
                <li> <i class="fas fa-check"></i> Assigning tasks </li>
                <li> <i class="fas fa-check"></i> 24/7 services </li>
            </ul>
            <a href="#" class="btn">choose plan</a>
        </div>
        <div class="box">
            <span class="fas fa-database"></span>
            <h3>Web Development</h3>
            <div class="price"> <i>₹</i>2000<i>/monthly</i> </div>
            <ul>
                <li> <i class="fas fa-check"></i> 4 months </li>
                <li> <i class="fas fa-check"></i> practicals </li>
                <li> <i class="fas fa-check"></i> Assigning tasks </li>
                <li> <i class="fas fa-check"></i> 24/7 services </li>
            </ul>
            <a href="#" class="btn">choose plan</a>
        </div>
        <div class="box">
            <span class="fas fa-file"></span>
            <h3>Projects</h3>
            <div class="price"> <i>₹</i>0<i>/monthly</i> </div>
            <ul>
                <li> <i class="fas fa-check"></i> 3 projects </li>
                <li> <i class="fas fa-check"></i> practicals </li>
                <li> <i class="fas fa-check"></i> Assigning tasks </li>
                <li> <i class="fas fa-check"></i> 24/7 services </li>
            </ul>
            <a href="#" class="btn">choose plan</a>
        </div>
    </div>
 </section>
 <div class="circle1"></div>
 <div class="circle2"></div>
 <!-- pricing section ends -->

  <br><br><h1 class="heading">Feat<span>ures</span> </h1>
   <section class="accordion">
            <div class="accordion__container">
                <div class="accordion__item">
                    <header class="accordion__header">
                        <i class='fas fa-plus accordion__icon'></i>
                        <h3 class="accordion__title">What's an accordion?</h3>
                    </header>
                    <div class="accordion__content">
                        <p class="accordion__description">An accordion always contains the category title, an expanded and a collapsed state, an icon indicating expansion, and the spacing between them.</p>
                    </div>
                </div>
                <div class="accordion__item">
                    <header class="accordion__header">
                        <i class='fas fa-plus accordion__icon'></i>
                        <h3 class="accordion__title">When and how should it be used?</h3>
                    </header>
                    <div class="accordion__content">
                        <p class="accordion__description">
                            It should be used when users only need a few key concepts or descriptions 
                            of the content on a single page.
                        </p>
                    </div>
                </div>
                <div class="accordion__item">
                    <header class="accordion__header">
                        <i class='fas fa-plus accordion__icon'></i>
                        <h3 class="accordion__title">What happens if the user clicks on a collapsed card while another card is open?</h3>
                    </header>
                    <div class="accordion__content">
                        <p class="accordion__description">
                            It happens that the open card was closed, to give way to the information of the next 
                            open card, but there are different designs that prefer it the other way around.
                        </p>
                    </div>
                </div>
                <div class="accordion__item">
                    <header class="accordion__header">
                        <i class='fas fa-plus accordion__icon'></i>
                        <h3 class="accordion__title">How to choose an icon to indicate expansion?</h3>
                    </header>
                    <div class="accordion__content">
                        <p class="accordion__description">
                            You must choose a different icon to open and close, so that the user 
                            understands what action he took.
                        </p>
                    </div>
                </div>
            </div>
        </section>
   <!-- features end -->
 
   <br><br><br><h1 class="heading">Choose<span>us</span> </h1>
   <div class="ball">
      <div class="med-card">
        <div class="circle">
          <img src="assets/images/chooseus/1.gif" alt=""/>
          <h3>Code Info</h3>
          <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit.</p>
          <div class="dots-items">
            <div class="dot"></div>
            <div class="dot"></div>
            <div class="dot"></div>
          </div>
        </div>
      </div>
      <div class="med-card">
        <div class="circle">
          <img src="assets/images/chooseus/2.gif" alt="" />
          <h3>Code Info</h3>
          <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit.</p>
          <div class="dots-items">
            <div class="dot"></div>
            <div class="dot"></div>
            <div class="dot"></div>
          </div>
        </div>
      </div>
      <div class="med-card">
        <div class="circle">
          <img src="assets/images/chooseus/3.gif" alt="" />
          <h3>Code Info</h3>
          <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit.</p>
          <div class="dots-items">
            <div class="dot"></div>
            <div class="dot"></div>
            <div class="dot"></div>
          </div>
        </div>
      </div>
      </div>

  <!-- Contact section start -->
  <h1 class="heading"><span>Contact</span>Us</h1>
  <section class="contact" id="contact">
      <div class="title reveal">
      </div>
      <div class="content">
        <div class="row">
          <div class="card reveal">
            <div class="contact-icon">
              <i class="fas fa-map-marker-alt"></i>
            </div>
            <div class="info">
              <h3>Address</h3>
              <span>Address, City, Country</span>
            </div>
          </div>
          <div class="card reveal">
            <div class="contact-icon">
              <i class="fas fa-phone"></i>
            </div>
            <div class="info">
              <h3>Phone</h3>
              <span>+00 0000 000 000</span>
            </div>
          </div>
          <div class="card reveal">
            <div class="contact-icon">
              <i class="fas fa-envelope"></i>
            </div>
            <div class="info">
              <h3>Email</h3>
              <span>contact@email.com</span>
            </div>
          </div>
        </div>   
      </div>
    </section>
    <div class="circle1"></div>
    <div class="circle2"></div><br><br><br>

    <!-- footer section starts  -->
    <?php include 'includes/footer.php' ?>
    <!-- footer section ends -->


    <!-- custom js file link  -->
    <script src="assets/js/script.js"></script>
    <!--=============== MAIN JS ===============-->
    <script src="assets/js/main.js"></script>

</body>
</html>