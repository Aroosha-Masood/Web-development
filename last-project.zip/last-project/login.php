<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complete glass website</title>
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <!--===== GSAP =====-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.5.1/gsap.min.js"></script>
  <!-- font awesome cdn link  -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <!-- custom css file link  -->
  <link rel="stylesheet" href="assets/css/login-css/style.css">
</head>
<body>

  <!-- header section starts  -->
   <header class="header">
    <a href="#" class="logo">AIM</a>
    <div class="icons">
        <div class="fas fa-moon" id="theme-btn"></div>
        <div class="fas fa-palette" id="color-btn"></div>
        <div class="fas fa-search" id="search-btn"></div>
        <div class="fas fa-bars" id="menu-btn"></div>
    </div>
    <nav class="navbar">
        <a class="active" href="index.php">Home</a>
        <a href="services.php">Services</a>
        <a href="gallery.php">Gallery</a>
        <a href="about.php">About us</a>
        <a href="code.php">Code</a>
        <a href="contact.php">Contact</a>
        <a href="login.php">login</a>
    </nav>
    <form action="" class="search-form">
        <input type="search" name="" placeholder="search here..." id="search-box">
        <label for="search-box" class="fas fa-search"></label>
    </form>
    <div class="colors-palette">
        <h3>choose color</h3>
        <div class="colors">
            <div class="color" style="background:#2980b9"></div>
            <div class="color" style="background: #27ae60;"></div>
            <div class="color" style="background: #e74c3c;"></div>
            <div class="color" style="background: #8e44ad;"></div>
            <div class="color" style="background: #B33771;"></div>
            <div class="color" style="background: #0fb9b1;"></div>
            <div class="color" style="background: #ff9f1a;"></div>
            <div class="color" style="background: #e84393;"></div>
            <div class="color" style="background: #17c0eb;"></div>
        </div>
    </header>
    
 
    <br><br><br><br><br><br><br><br><br><br><br><h3 class="heading"><span>Welcome Back!</span></h3>
    <form>
        <h1 class="heading">Login<span>Here</span></h1>
        <label for="username">Username</label>
        <input type="text" placeholder="Username" id="username">
        <label for="password">Password</label>
        <input type="password" placeholder="Password" id="password">
        <br><br><a href="#" type="submit" name="submit" value="submit" class="btn">Login</a>
    </form>


    <!-- custom js file link  -->
    <script src="assets/js/script.js"></script>
    <!--=============== MAIN JS ===============-->
    <script src="assets/js/main.js"></script>

</body>
</html>