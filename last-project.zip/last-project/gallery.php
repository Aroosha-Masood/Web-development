<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complete glass website</title>
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <!--===== GSAP =====-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.5.1/gsap.min.js"></script>
  <!-- font awesome cdn link  -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <!-- custom css file link  -->
  <link rel="stylesheet" href="assets/css/gallery-css/style.css">
</head>
<body>

<!-- header section starts  -->
<div class="glass-container">
 <header class="header">
    <a href="#" class="logo">AIM</a>
    <div class="icons">
        <div class="fas fa-moon" id="theme-btn"></div>
        <div class="fas fa-palette" id="color-btn"></div>
        <div class="fas fa-search" id="search-btn"></div>
        <div class="fas fa-bars" id="menu-btn"></div>
    </div>
    <nav class="navbar">
        <a class="active" href="index.php">Home</a>
        <a href="services.php">Services</a>
        <a href="gallery.php">Gallery</a>
        <a href="about.php">About us</a>
        <a href="code.php">Code</a>
        <a href="contact.php">Contact</a>
        <a href="login.php">login</a>
    </nav>
    <form action="" class="search-form">
        <input type="search" name="" placeholder="search here..." id="search-box">
        <label for="search-box" class="fas fa-search"></label>
    </form>
    <div class="colors-palette">
        <h3>choose color</h3>
        <div class="colors">
            <div class="color" style="background:#2980b9"></div>
            <div class="color" style="background: #27ae60;"></div>
            <div class="color" style="background: #e74c3c;"></div>
            <div class="color" style="background: #8e44ad;"></div>
            <div class="color" style="background: #B33771;"></div>
            <div class="color" style="background: #0fb9b1;"></div>
            <div class="color" style="background: #ff9f1a;"></div>
            <div class="color" style="background: #e84393;"></div>
            <div class="color" style="background: #17c0eb;"></div>
        </div>
    </div>
 </header>
 <!-- header section ends -->
  <section class="main" id="main">
        <div class="content">
        <h2>Our<br><span>Gallery</span></h2>
        <div class="animated-text">
          <h3>Aroosha</h3>
          <h3>Anum</h3>
          <h3>Rida</h3>
        </div><br>
        <a href="#" class="btn">choose plan</a>
      </div>
    <div class="GIF"><i class="fas fa-photo-video"></i></i></div>
    </section>
    </div>
    <div class="circle1"></div>
    <div class="circle2"></div>
 <!-- header end -->

   <!-- gallery section starts  -->
  <section class="gallery" id="gallery">
    <h1 class="heading"> Our <span>gallery</span> </h1>
    <div class="box-container">
        <div class="box">
            <img src="assets/images/gallery/A1.png" alt="">
            <div class="content">
                <h3>project 01</h3>
                <span>01/09/2021</span>
            </div>
        </div>
        <div class="box">
            <img src="assets/images/gallery/p2.png" alt="">
            <div class="content">
                <h3>project 02</h3>
                <span>01/09/2021</span>
            </div>
        </div>
        <div class="box">
            <img src="assets/images/gallery/A3.png" alt="">
            <div class="content">
                <h3>project 03</h3>
                <span>01/09/2021</span>
            </div>
        </div>
        <div class="box">
            <img src="assets/images/gallery/p3.png" alt="">
            <div class="content">
                <h3>project 04</h3>
                <span>01/09/2021</span>
            </div>
        </div>
        <div class="box">
            <img src="assets/images/gallery/A2.png" alt="">
            <div class="content">
                <h3>project 05</h3>
                <span>01/09/2021</span>
            </div>
        </div>
        <div class="box">
            <img src="assets/images/gallery/p8.png" alt="">
            <div class="content">
                <h3>project 06</h3>
                <span>01/09/2021</span>
            </div>
        </div>
    </div>
 </section>
 <div class="circle1"></div>
 <div class="circle2"></div>
 <!-- gallery section ends -->


   <!-- gallery section starts  -->
  <section class="gallery" id="gallery">
    <h1 class="heading"> Students <span>Work</span> </h1>
    <div class="box-container">
        <div class="box">
            <img src="assets/images/gallery/1.png" alt="">
            <div class="content">
                <h3>project 01</h3>
                <span>01/09/2021</span>
            </div>
        </div>
        <div class="box">
            <img src="assets/images/gallery/2.png" alt="">
            <div class="content">
                <h3>project 02</h3>
                <span>01/09/2021</span>
            </div>
        </div>
        <div class="box">
            <img src="assets/images/gallery/3.png" alt="">
            <div class="content">
                <h3>project 03</h3>
                <span>01/09/2021</span>
            </div>
        </div>
        <div class="box">
            <img src="assets/images/gallery/4.png" alt="">
            <div class="content">
                <h3>project 04</h3>
                <span>01/09/2021</span>
            </div>
        </div>
        <div class="box">
            <img src="assets/images/gallery/5.png" alt="">
            <div class="content">
                <h3>project 05</h3>
                <span>01/09/2021</span>
            </div>
        </div>
        <div class="box">
            <img src="assets/images/gallery/6.png" alt="">
            <div class="content">
                <h3>project 06</h3>
                <span>01/09/2021</span>
            </div>
        </div>
    </div>
 </section>
 <div class="circle1"></div>
 <div class="circle2"></div>
 <!-- gallery section ends -->

 <!-- gallery section starts  -->
  <section class="gallery" id="gallery">
    <h1 class="heading"> Students <span>Projects</span> </h1>
    <div class="box-container">
        <div class="box">
            <img src="assets/images/gallery/7.png" alt="">
            <div class="content">
                <h3>project 01</h3>
                <span>01/09/2021</span>
            </div>
        </div>
        <div class="box">
            <img src="assets/images/gallery/8.png" alt="">
            <div class="content">
                <h3>project 02</h3>
                <span>01/09/2021</span>
            </div>
        </div>
        <div class="box">
            <img src="assets/images/gallery/9.png" alt="">
            <div class="content">
                <h3>project 03</h3>
                <span>01/09/2021</span>
            </div>
        </div>
        <div class="box">
            <img src="assets/images/gallery/10.png" alt="">
            <div class="content">
                <h3>project 04</h3>
                <span>01/09/2021</span>
            </div>
        </div>
        <div class="box">
            <img src="assets/images/gallery/11.png" alt="">
            <div class="content">
                <h3>project 05</h3>
                <span>01/09/2021</span>
            </div>
        </div>
        <div class="box">
            <img src="assets/images/gallery/12.png" alt="">
            <div class="content">
                <h3>project 06</h3>
                <span>01/09/2021</span>
            </div>
        </div>
    </div>
 </section>
 <div class="circle1"></div>
 <div class="circle2"></div>
 <!-- gallery section ends -->
 
 
    <!-- gallery section starts  -->
  <section class="gallery" id="gallery">
    <h1 class="heading"> Team <span>Projects</span> </h1>
    <div class="box-container">
        <div class="box">
            <img src="assets/images/gallery/13.png" alt="">
            <div class="content">
                <h3>project 01</h3>
                <span>01/09/2021</span>
            </div>
        </div>
        <div class="box">
            <img src="assets/images/gallery/14.png" alt="">
            <div class="content">
                <h3>project 02</h3>
                <span>01/09/2021</span>
            </div>
        </div>
        <div class="box">
            <img src="assets/images/gallery/15.png" alt="">
            <div class="content">
                <h3>project 03</h3>
                <span>01/09/2021</span>
            </div>
        </div>
        <div class="box">
            <img src="assets/images/gallery/16.png" alt="">
            <div class="content">
                <h3>project 04</h3>
                <span>01/09/2021</span>
            </div>
        </div>
        <div class="box">
            <img src="assets/images/gallery/17.png" alt="">
            <div class="content">
                <h3>project 05</h3>
                <span>01/09/2021</span>
            </div>
        </div>
        <div class="box">
            <img src="assets/images/gallery/18.png" alt="">
            <div class="content">
                <h3>project 06</h3>
                <span>01/09/2021</span>
            </div>
        </div>
    </div>
 </section>
 <div class="circle1"></div>
 <div class="circle2"></div>
 <!-- gallery section ends -->
    

  <!-- footer section starts  -->
   <?php include 'includes/footer.php' ?>
  <!-- footer section ends -->
  
    <!-- custom js file link  -->
    <script src="assets/js/script.js"></script>
    <!--=============== MAIN JS ===============-->
    <script src="assets/js/main.js"></script>

</body>
</html>