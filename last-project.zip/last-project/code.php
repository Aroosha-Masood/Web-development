<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complete glass website</title>
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <!--===== GSAP =====-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.5.1/gsap.min.js"></script>
  <!-- font awesome cdn link  -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <!-- custom css file link  -->
  <link rel="stylesheet" href="assets/css/code-css/style.css">
</head>
<body>

<!-- header section starts  -->
<div class="glass-container">
 <header class="header">
    <a href="#" class="logo">AIM</a>
    <div class="icons">
        <div class="fas fa-moon" id="theme-btn"></div>
        <div class="fas fa-palette" id="color-btn"></div>
        <div class="fas fa-search" id="search-btn"></div>
        <div class="fas fa-bars" id="menu-btn"></div>
    </div>
    <nav class="navbar">
        <a class="active" href="index.php">Home</a>
        <a href="services.php">Services</a>
        <a href="gallery.php">Gallery</a>
        <a href="about.php">About us</a>
        <a href="code.php">Code</a>
        <a href="contact.php">Contact</a>
        <a href="login.php">login</a>
    </nav>
    <form action="" class="search-form">
        <input type="search" name="" placeholder="search here..." id="search-box">
        <label for="search-box" class="fas fa-search"></label>
    </form>
    <div class="colors-palette">
        <h3>choose color</h3>
        <div class="colors">
            <div class="color" style="background:#2980b9"></div>
            <div class="color" style="background: #27ae60;"></div>
            <div class="color" style="background: #e74c3c;"></div>
            <div class="color" style="background: #8e44ad;"></div>
            <div class="color" style="background: #B33771;"></div>
            <div class="color" style="background: #0fb9b1;"></div>
            <div class="color" style="background: #ff9f1a;"></div>
            <div class="color" style="background: #e84393;"></div>
            <div class="color" style="background: #17c0eb;"></div>
        </div>
    </div>
 </header>
 <!-- header section ends -->
  <section class="main" id="main">
        <div class="content">
        <h2>Get<br><span>code</span> From here</h2>
        <div class="animated-text">
          <h3>Anum</h3>
          <h3>Rida</h3>
          <h3>Aroosha</h3>
        </div><br>
        <a href="#" class="btn">choose plan</a>
      </div>
    <div class="GIF"><i class="fas fa-laptop-code"></i></i></div>
    </section>
    </div>
    <div class="circle1"></div>
    <div class="circle2"></div>
 <!-- header end -->
 


 <!-- Clock start -->
 <br><br><br><h1 class="heading"><span>JavaScript,</span> HTML <span>and</span> CSS<span> Clock</span></h1>
 <div class="text-boxes">
  <div class="text-box htmlBox">
  <div class="topic">HTML Code</div>
   <textarea readonly id="HtmlCode">
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://kit.fontawesome.com/6f17055eb8.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="style.css">
        <title>Button</title>
    </head>
    <body>
        <button  class="btn">
            <span class="txt">Botton</span>
            <span class="round"><i class="fa fa-chevron-right"></i></span>
        </button>
    </body>
    </html>
         </textarea>
         <button class="btn" id="HtmlBtn">Copy Code</button>
      </div>
      <div class="text-box htmlBox">
     <div class="topic">CSS Code</div>
     <textarea readonly id="CSSCode">*
        {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: sans-serif;
        }
        button
        {
            position: relative;
            display: inline-block;
            text-decoration: none;
            padding: 12px 53px 12px 23px;
            color: #fff;
            background-color: #f3c40f;
            border: none;
            outline: none;
            border-radius: 30px;
            text-transform: uppercase;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
        }
        button span
        {
            position: relative;
            z-index: 3;
        }
        button .round
        {
            border-radius: 50%;
            width: 38px;
            height: 38px;
            position: absolute;
            right: 3px;
            top: 3px;
            background-color: #f8d23b;
            transition: all 0.3s ease-out;
            z-index: 2;
        }
        button .round i
        {
            position: absolute;
            top: 50%;
            margin-top: -6px;
            left: 50%;
            margin-left: -4px;
            transition: all 0.3s;
        }
        .txt
        {
            font-size: 14px;
            line-height: 1.45;
        }
        button:hover
        {
            padding-left: 48px;
            padding-right: 28px;
        }
        button:hover .round
        {
            width: calc(100% - 6px);
            border-radius: 30px;
        }
        button:hover .round i
        {
            left: 12%;
        }
         </textarea>
         <button class="btn" id="CSSBtn">Copy Code</button>
      </div>
   </div>
   <script>
      const HtmlBtn = document.getElementById('HtmlBtn');
      const HtmlCode = document.getElementById('HtmlCode');
      HtmlBtn.addEventListener('click',()=>{
         HtmlCode.select();
         document.execCommand('copy');
         HtmlBtn.innerHTML = "Code Copied"
      });
      const CSSBtn = document.getElementById('CSSBtn');
      const CSSCode = document.getElementById('CSSCode');
      CSSBtn.addEventListener('click',()=>{
         CSSCode.select();
         document.execCommand('copy');
         CSSBtn.innerHTML = "Code Copied"
      })
   </script>
    <center><a href="https://drive.google.com/file/d/1nmuiPckZaVehDzem61hsEeLQ-y7XNwBe/view?usp=sharing" class="btn">Download Full file from Here</a></center>
     <!-- Clock end -->

    

    <!-- Calculator start -->
    <br><br><br><br><h1 class="heading"><span>JavaScript,</span> HTML <span>and</span> CSS<span> Calculator</span></h1>
     <div class="text-boxes">
      <div class="text-box htmlBox">
         <div class="topic">HTML Code</div>
         <textarea readonly id="HtmlCode">
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <title>Calculator</title>
                <link rel="stylesheet" href="style.css">
            </head>
            <body>
                <form class="Calculator" name="calc">
                <input class="value" type="text" name="txt" readonly="">
                <span class="num clear" onclick="document.calc.txt.value =''">c</span>
                <span class="num" onclick="document.calc.txt.value +='/'">/</span>
                <span class="num" onclick="document.calc.txt.value +='*'">*</span>
                <span class="num" onclick="document.calc.txt.value +='7'">7</span>
                <span class="num" onclick="document.calc.txt.value +='8'">8</span>
                <span class="num" onclick="document.calc.txt.value +='9'">9</span>
                <span class="num " onclick="document.calc.txt.value +='-'">-</span>
                <span class="num" onclick="document.calc.txt.value +='4'">4</span>
                <span class="num" onclick="document.calc.txt.value +='5'">5</span>
                <span class="num" onclick="document.calc.txt.value +='6'">6</span>
                <span class="num plus" onclick="document.calc.txt.value +='+'">+</span>
                <span class="num" onclick="document.calc.txt.value +='3'">3</span>
                <span class="num" onclick="document.calc.txt.value +='2'">2</span>
                <span class="num" onclick="document.calc.txt.value +='1'">1</span>
                <span class="num" onclick="document.calc.txt.value +='0'">0</span>
                <span class="num" onclick="document.calc.txt.value +='00'">00</span>
                <span class="num" onclick="document.calc.txt.value +='.'">.</span>
                <span class="num equal" onclick="document.calc.txt.value =eval(calc.txt.value)">=</span>
                </form>
            </body>
            </html>
         </textarea>
         <button class="btn" id="HtmlBtn">Copy Code</button>
      </div>
      <div class="text-box htmlBox">
        <div class="topic">CSS Code</div>
        <textarea readonly id="CSSCode">
        @import url('https://fonts.googleapis.com/css?family=Poppins: 300,400,500,600,700,800,900&display=swap');
            *
            {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
                font-family: 'Poppins' , sans-serif;
            }
            body
            {
                display: flex;
                justify-content: center;
                align-items: center;
                min-height: 100vh;
                background: #091921;
            }
            .Calculator
            {
                position: relative;
                display: grid;
            }
            .Calculator .value
            {
                grid-column: span 4;
                height: 100px;
                text-align: right;
                border: none;
                outline: none;
                padding: 10px;
                font-size: 18px;
            }
            .Calculator span
            {
                display: grid;
                width: 60px;
                height: 60px;
                color: #fff;
                background: #0c2835;
                place-items: center;
                border: 1px solid rgba(0,0,0,.1);

            }
            .Calculator span:active
            {
                background: #74ff3b;
                color: #111;
            }
            .Calculator span.clear
            {
               grid-column: span 2;
               width: 120px;
               background: #ff3077;
            }
            .Calculator span.plus
            {
               grid-row: span 2;
               height: 120px;
            }
            .Calculator span.equal
            {
               background: #03b1ff;

            }
         </textarea>
         <button class="btn" id="CSSBtn">Copy Code</button>
      </div>
   </div>
   <script>
      const HtmlBtn = document.getElementById('HtmlBtn');
      const HtmlCode = document.getElementById('HtmlCode');
      HtmlBtn.addEventListener('click',()=>{
         HtmlCode.select();
         document.execCommand('copy');
         HtmlBtn.innerHTML = "Code Copied"
      });
      const CSSBtn = document.getElementById('CSSBtn');
      const CSSCode = document.getElementById('CSSCode');
      CSSBtn.addEventListener('click',()=>{
         CSSCode.select();
         document.execCommand('copy');
         CSSBtn.innerHTML = "Code Copied"
      })
   </script>
    <center><a href="https://drive.google.com/file/d/1nmuiPckZaVehDzem61hsEeLQ-y7XNwBe/view?usp=sharing" class="btn">Download Full file from Here</a></center>
     <!-- Calculator end -->



  <!-- Contact start -->
   <br><br><br><br><h1 class="heading"><span>HTML</span> and <span>CSS</span> Contact<span> Cards</span></h1><div class="text-boxes">
      <div class="text-box htmlBox">
         <div class="topic">HTML Code</div>
         <textarea readonly id="HtmlCode">
        <!DOCTYPE html>
        <html lang="en" dir="ltr">
          <head>
            <meta charset="utf-8">
            <title></title>
            <link rel="stylesheet" href="style.css">
            <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
          </head>
          <body>
            <div class="container">
              <div class="contact-method">
                <i class="fas fa-envelope"></i>
                <span>example@domain.com</span>
              </div>
              <div class="contact-method">
                <i class="fas fa-mobile-alt"></i>
                <span>+111111111111</span>
              </div>
              <div class="contact-method">
                <i class="fas fa-map-marker-alt"></i>
                <span>New York US</span>
              </div>
            </div>
          </body>
        </html>
         </textarea>
         <button class="btn" id="HtmlBtn">Copy Code</button>
      </div>
      <div class="text-box htmlBox">
     <div class="topic">CSS Code</div>
     <textarea readonly id="CSSCode">
        body
        {
          margin: 0;
          padding: 0;
          font-family: "montserrat",sans-serif;
        }
        .container
        {
          position: absolute;
          width: 100%;
          top: 50%;
          transform: translateY(-50%);
          text-align: center;
        }
        .contact-method
        {
          width: 220px;
          height: 140px;
          display: inline-block;
          background: #3498db;
          margin: 10px;
          color: #fff;
          position: relative;
          cursor: pointer;
        }
        .contact-method i
        {
          position: absolute;
          left: 0;
          top: 0;
          width: 100%;
          height: 100%;
          font-size: 30px;
          line-height: 140px;
          background: #34495e;
          z-index: 1;
          transition: transform 0.6s;
        }
        .contact-method span
        {
          position: absolute;
          width: 100%;
          left: 0;
          bottom: 0;
          padding: 10px 0;
        }
        .contact-method:hover i
        {
          transform: translateY(-40px);
        }
     </textarea>
         <button class="btn" id="CSSBtn">Copy Code</button>
      </div>
   </div>
   <script>
      const HtmlBtn = document.getElementById('HtmlBtn');
      const HtmlCode = document.getElementById('HtmlCode');
      HtmlBtn.addEventListener('click',()=>{
         HtmlCode.select();
         document.execCommand('copy');
         HtmlBtn.innerHTML = "Code Copied"
      });
      const CSSBtn = document.getElementById('CSSBtn');
      const CSSCode = document.getElementById('CSSCode');
      CSSBtn.addEventListener('click',()=>{
         CSSCode.select();
         document.execCommand('copy');
         CSSBtn.innerHTML = "Code Copied"
      })
   </script>
    <center><a href="https://drive.google.com/file/d/1nmuiPckZaVehDzem61hsEeLQ-y7XNwBe/view?usp=sharing" class="btn">Download Full file from Here</a></center>
     <!-- Contact end -->

  <!-- footer section starts  -->
   <?php include 'includes/footer.php' ?>
  <!-- footer section ends -->

    <!-- custom js file link  -->
    <script src="assets/js/script.js"></script>
    <!--=============== MAIN JS ===============-->
    <script src="assets/js/main.js"></script>

</body>
</html>