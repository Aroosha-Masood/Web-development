<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complete glass website</title>
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <!--===== GSAP =====-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.5.1/gsap.min.js"></script>
  <!-- font awesome cdn link  -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <!-- custom css file link  -->
  <link rel="stylesheet" href="assets/css/about-css/style.css">
</head>
<body>

<!-- header section starts  -->
<div class="glass-container">
 <header class="header">
    <a href="#" class="logo">AIM</a>
    <div class="icons">
        <div class="fas fa-moon" id="theme-btn"></div>
        <div class="fas fa-palette" id="color-btn"></div>
        <div class="fas fa-search" id="search-btn"></div>
        <div class="fas fa-bars" id="menu-btn"></div>
    </div>
    <nav class="navbar">
        <a href="index.php">Home</a>
        <a href="services.php">Services</a>
        <a href="gallery.php">Gallery</a>
        <a class="active" href="about.php">About us</a>
        <a href="code.php">Code</a>
        <a href="contact.php">Contact</a>
        <a href="login.php">login</a>
    </nav>
    <form action="" class="search-form">
        <input type="search" name="" placeholder="search here..." id="search-box">
        <label for="search-box" class="fas fa-search"></label>
    </form>
    <div class="colors-palette">
        <h3>choose color</h3>
        <div class="colors">
            <div class="color" style="background:#2980b9"></div>
            <div class="color" style="background: #27ae60;"></div>
            <div class="color" style="background: #e74c3c;"></div>
            <div class="color" style="background: #8e44ad;"></div>
            <div class="color" style="background: #B33771;"></div>
            <div class="color" style="background: #0fb9b1;"></div>
            <div class="color" style="background: #ff9f1a;"></div>
            <div class="color" style="background: #e84393;"></div>
            <div class="color" style="background: #17c0eb;"></div>
        </div>
    </div>
 </header>
  <!-- header section ends -->
  <section class="main" id="main">
      <div class="content">
        <h2>It's all<br><span>About</span>us</h2>
        <div class="animated-text">
          <h3>Our Team</h3>
          <h3>Organization</h3>
          <h3>Establishment</h3>
        </div><br>
        <a href="#" class="btn">See More</a>
      </div>
      <img class="GIF" src="assets/images/header/2.png">
    </section>
    </div>
    <div class="circle1"></div>
    <div class="circle2"></div>
  <!-- header end -->

  <!-- about us section starts-->
 <br><br><br><h1 class="heading">About<span>US</span></h1>
 <div class="profile-card">
    <div class="card-header">
      <div class="pic">
        <img src="assets/images/about/1.jpeg" alt="">
      </div>
      <div class="name">IT BAAR</div>
      <div class="desc">As every organization has a biggest strength behind it and that is their management and team working. Without proper team coordination an organization can’t achieve success. Any institute or an organization is nothing without their team and they can’t even survive.</div>
      <div class="center">
         <div class="icons first">
            <li><a href="https://www.facebook.com/"><span class="fab fa-facebook-f"></span></a></li>
            <li><a href="https://twitter.com/home?lang=en"><span class="fab fa-twitter"></span></a></li>
            <li><a href="https://www.instagram.com/"><span class="fab fa-instagram"></span></a></li>
            <li><a href="https://www.linkedin.com/feed/"><span class="fab fa-linkedin-in"></span></a></li>
            <li><a href="https://github.com/"><span class="fab fa-github"></span></a></li>
         </div>
      </div>
     <script>
         $('.first li').click(function(){
           $(this).toggleClass("shadow-1").siblings();
           $(this).toggleClass("fill-color").siblings();
         });
      </script>
    </div>
    <div class="card-footer">
      <div class="numbers">
        <div class="item">
          <span>Owners</span>2</div>
        <div class="border"></div>
        <div class="item">
          <span>Manager</span>1</div>
        <div class="border"></div>
        <div class="item">
          <span>Team</span>2</div>
      </div>
    </div>
  </div>
  <!-- about section end -->

<!--    <br><br><h1 class="heading">Our <span>Team</span></h1>
   <div class="team_section">
   <div class="team-card">
        <div class="circle">
            <div class="imgBox">
                <img src="assets/images/team/1.png" alt="">
            </div>
        </div>
        <div class="team-content">
            <a href="#">
                <i class="fas fa-linkedin" aria-hidden="true"></i>
            </a>
            <h3>James Ford</h3>
            <div class="textIcon">
                <h4>Director General</h4>
                <a href="#">
                    <i class="fa fa-arrow-right" aria-hidden="true"></i>
                </a>
            </div>
        </div>
    </div>
    <div class="team-card">
        <div class="circle">
            <div class="imgBox">
                <img src="assets/images/team/2.png" alt="">
            </div>
        </div>
        <div class="team-content">
            <a href="#">
                <i class="fas fa-linkedin" aria-hidden="true"></i>
            </a>
            <h3>Ann Brown</h3>
            <div class="textIcon">
                <h4>Mannager</h4>
                <a href="#">
                    <i class="fa fa-arrow-right" aria-hidden="true"></i>
                </a>
            </div>
        </div>
    </div>
    <div class="team-card">
        <div class="circle">
            <div class="imgBox">
                <img src="assets/images/team/3.png" alt="">
            </div>
        </div>
        <div class="team-content">
            <a href="#">
                <i class="fas fa-linkedin" aria-hidden="true"></i>
            </a>
            <h3>Ben Jason</h3>
            <div class="textIcon">
                <h4>Developer</h4>
                <a href="#">
                    <i class="fa fa-arrow-right" aria-hidden="true"></i>
                </a>
            </div>
        </div>
      </div>
    </div>
    <!--  team end  -->
 -->
  <!-- review section starts  -->
   <br><br><section class="review" id="review">
    <h1 class="heading"> Client's <span>review</span> </h1>
    <div class="box-container">
        <div class="box">
            <div class="user">
                <img src="assets/images/team/pic-1.png" alt="">
                <div class="info">
                    <h3>john deo</h3>
                </div>
                <i class="fas fa-quote-right"></i>
            </div>
            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Nemo ut veniam modi vitae ad explicabo, provident iusto, officiis voluptatibus debitis possimus sequi blanditiis mollitia excepturi repellendus omnis non doloremque expedita?</p>
        </div>
        <div class="box">
            <div class="user">
                <img src="assets/images/team/pic-2.png" alt="">
                <div class="info">
                    <h3>john deo</h3>
                </div>
                <i class="fas fa-quote-right"></i>
            </div>
            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Nemo ut veniam modi vitae ad explicabo, provident iusto, officiis voluptatibus debitis possimus sequi blanditiis mollitia excepturi repellendus omnis non doloremque expedita?</p>
        </div>
        <div class="box">
            <div class="user">
                <img src="assets/images/team/pic-3.png" alt="">
                <div class="info">
                    <h3>john deo</h3>
                </div>
                <i class="fas fa-quote-right"></i>
            </div>
            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Nemo ut veniam modi vitae ad explicabo, provident iusto, officiis voluptatibus debitis possimus sequi blanditiis mollitia excepturi repellendus omnis non doloremque expedita?</p>
        </div>
    </div>
  </section>
  <div class="circle1"></div>
  <div class="circle2"></div>

  <!-- footer section starts  -->
   <?php include 'includes/footer.php' ?>
  <!-- footer section ends -->

    <!-- custom js file link  -->
    <script src="assets/js/script.js"></script>
    <!--=============== MAIN JS ===============-->
    <script src="assets/js/main.js"></script>

</body>
</html>